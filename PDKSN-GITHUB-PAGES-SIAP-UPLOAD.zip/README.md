# TOKO BUAH PD.KSN — Daftar Harga

Berkas `index.html` adalah dashboard mandiri untuk GitHub Pages.

## Cara menayangkan
1. Buat repository GitHub baru bernama `pdksn-daftar-harga` dengan visibilitas **Public**.
2. Unggah `index.html` ke folder paling atas repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**, branch `main`, folder `/ (root)`, lalu **Save**.
5. Tunggu beberapa menit. Tautan situs akan muncul di halaman Pages.

Catatan: halaman GitHub Pages dapat dibuka umum. Perubahan harga tetap tersimpan di browser/perangkat tempat perubahan dibuat; tidak otomatis tersinkron antarperangkat.
